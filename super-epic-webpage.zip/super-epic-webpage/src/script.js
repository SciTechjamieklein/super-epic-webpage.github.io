let yam = 0;
function yoy() {
  yam++;
  if (yam != 100) {
    alert("yippee" + " you have " + yam + " yippees");
  } else {
    alert("...you can stop now... you have...100 yippees.");
  }
}
